package converter;
import javax.swing.JOptionPane;
import edu.cmu.ri.createlab.terk.robot.finch.Finch;

 

public class converter 
	{
	public static  String in;
	public static int toDecimal(String hex) {  
		
		String digits = "0123456789ABCDEF";  
		
		
		hex = hex.toUpperCase();  //converts to upper case
		int val = 0;  
		for (int i = 0; i < hex.length(); i++)  
	{  
		char c = hex.charAt(i);  
		int d = digits.indexOf(c);  
		val = 16*val + d;  

	}  
		return val;  
	}
	
	
	public static String toBinary(int decimal)
	{  
		
		int binary[] = new int[20];    
		int index = 0;   
		StringBuilder str = new StringBuilder();
		while(decimal > 0){    
			binary[index++] = decimal%2;    
			decimal = decimal/2;    
	}    
		 
		for(int i = index-1;i >= 0;i--)
	{    
			str.append(binary[i]);    
	}    
		return str.toString();
		 
	}    


	public static String toOctal(int decimal)
	{  
		
		int octal[] = new int[40];    
		int index = 0;   
		StringBuilder str = new StringBuilder();
		while(decimal > 0)
	{    
			octal[index++] = decimal%8;    
			decimal = decimal/8;    
	}    
	
		for(int i = index-1;i >= 0;i--){    
			str.append(octal[i]);    
	}    
		return str.toString();
	}
	
	
	public static void finchMovement(int dec, String in) {
	String l = toOctal(dec);
	int speed = Integer.parseInt(l);
	Finch myFinch = new Finch();
	
	String movement = toBinary(dec);
	
	for(int i = movement.length()-1; i >= 0; i--){
	   
		if(movement.charAt(i) == '1') {
	     
	    	if(speed > 255)
		
	    		myFinch.setWheelVelocities(255, 255, 1000); 
		}
	
	    	else if(speed < 60) {
	
	    		myFinch.setWheelVelocities(speed + 30, speed + 30, 1000);
	    	}
		
	    	else {
	
	    		myFinch.setWheelVelocities(speed, speed, 1000);
	    	}
	        
	        	myFinch.buzz(440, 1000);
	    
	
		if(movement.charAt(i) == '0') {
	   
			if(speed > -255) {
		 
				myFinch.setWheelVelocities(-255, -255, 1000);
			}
	   
			else if(speed < 60) {
		 
				myFinch.setWheelVelocities(-speed + 30, -speed + 30, 1000);
			}
	   
			else {
	  	
				myFinch.setWheelVelocities(-speed, -speed, 1000);
			}
		
		        myFinch.buzz(320, 1000); 
		}
	}
	}
	 
	
	public static void finchLED(String in, Finch myFinch) {
	int red = toDecimal(in);
	
	int green = red % 80 + 60;
	
	int blue = (red + green) / 2; 
	
	myFinch.setLED(red, green, blue);
	
	}
		
	
    
	
	  
	
	  public static void main(String args[])

    { 
		
		boolean isValidInput = false;
		
		while (isValidInput == false) 
		
	{
	           
			 in = JOptionPane.showInputDialog(null, "Please enter a hexadecimal number: ");
			 int c = Integer.valueOf(in);
			 System.out.println("The hexadecimal you entered is:  " + (c));
			 
			
				
		if (!in.matches("[1-9 A-F][0-5frf  9 A-F]")) {
			System.out.println("Error: Please make sure there are 2 digits. First digit ranges from 1-9 or A-F and second digit ranges from 0-9 or A-F");
			JOptionPane.showMessageDialog(null, "Error: Please make sure there are 2 digits. First digit ranges from 1-9 or A-F and second digit ranges from 0-9 or A-F");
					
	}
				
		else 
    {
					
		toDecimal(in);

		JOptionPane.showMessageDialog(null, "The decimal equivalent is: "+toDecimal(in));
		int dec = toDecimal(in);
		JOptionPane.showMessageDialog(null, "The hexadecimal you entered is: "+(in));
		JOptionPane.showMessageDialog(null, "The binary equivalent is: "+toBinary(dec));
		JOptionPane.showMessageDialog(null, "The octal equivalent is: "+toOctal(dec));
		System.out.println("The hexadecimal you entered is:  "+ (in));
		System.out.println("Decimal value is: "+toDecimal(in));
		System.out.println("Octal value is: "+toOctal(dec));
		System.out.println("Binary value is: "+toBinary(dec));
		isValidInput = true;
		finchMovement(dec, in);
		finchLED(in, null);
			
	}

	}
	}

	}
	    
    
    
    
   



	